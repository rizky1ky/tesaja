# Usage Tools Windows
- Install Xampp
- Add Path PHP (https://dinocajic.medium.com/add-xampp-php-to-environment-variables-in-windows-10-af20a765b0ce)
- Install Git Clone
- Git clone https://github.com/arimaulanafirmansyah/spotitit
- cd spotitit
- php index.php

# Usage Tools Termux
- pkg update
- pkg upgrade
- pkg install php
- pkg install git
- git clone https://github.com/arimaulanafirmansyah/spotitit
- cd spotitit
- php index.php

# Tools Spotify Premium 3 Bulan Samsung
Tidak Perlu Pay Di Aplikasi
- Run Tools 
- Buka Link Yang Di Suruh
- Login Akun Sesuai Yang Di Buat Oleh Tools
- Pay Pake VCC Kalian 🙂
Link Plan : https://www.spotify.com/id/redirect-in-app/android_premium_promotion/?offerSlug=samsung-global2022-pdp-3m-3m-trial-one-time-code
# Donate 
Dana : 085157792618


# SOURCE
Agatha Sangkara
